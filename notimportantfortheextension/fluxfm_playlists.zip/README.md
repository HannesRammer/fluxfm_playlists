# fluxfl_playlists
Enhancment for the radioplayer on https://www.fluxfm.de/stream/ 

now you can see all active playing songs from over 30 channels. 
before you had to load the station to see whats been played, 
so you can chose what radiosation to switch to
hide radio channels 
like and dislike songs 
and 
(beta)
next time a disliked song would get played, the player skips to a different station, 
preferable to one where a liked song is played

https://chrome.google.com/webstore/detail/fluxfm-playlists/kemkofgcgndgeapggchfhoihfmnjobdo?hl=de

