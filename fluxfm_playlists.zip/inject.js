// Create the XHR object.
function createCORSRequest(method, url){
    var request = new XMLHttpRequest();
    if ("withCredentials" in request){
        request.open(method, url, true);
    } else if (typeof XDomainRequest != "undefined"){
        request = new XDomainRequest();
        request.open(method, url);
    } else {
        request = null;
    }
    return request;
}

var alreadyAddedToPlaylist=[];

// Make the actual CORS request.
function makeCorsRequest(requestUrl) {
    //var url = 'http://updates.html5rocks.com';
    var request = createCORSRequest("GET", requestUrl);
    if (!request) {
        throw new Error('CORS not supported');
    }
    if (request){
        request.withCredentials = true;
        request.setRequestHeader('Access-Control-Allow-Origin', '*');
        request.setRequestHeader('Content-Type', 'application/json' );
        request.setRequestHeader('X-Custom-Header', 'fluxplaylists');
        request.onerror = function() {
              alert('Woops, there was an error making the request.');
        };
        //request.onload = function(){
        //};
        request.onreadystatechange = function() {
            if(request.readyState == 4 && request.status == 200) {
                var data = JSON.parse(request.responseText);
                var title = "title";
                //getTitle(data);
                console.log('Response from CORS request to ' + requestUrl + ': ' + title);
                var id = "playlist_"+requestUrl.split("loc=")[1];
                var div = document.getElementById(id);
                //var li = document.createElement("li");
                //li.innerText = (data.tracks[0].artist +" - "+ data.tracks[0].title).replace(/ +(?= )/g,'').trim();
                //$(data.tracks).appendTo($("#"+div.id));
                var tmpl = $.tmpl(`<li playlistid="\${id}" class="playlist">
                      <div class="kaufen" style="display:none">
                      <a href="http://www.amazon.de/s?ie=UTF8&keywords=\${artist}%20\${title}&tag=httpwwwfluxfm-21&index=blended&link_code=qs" target="_blank">
                      <img src="./images/amazon.png" alt="Kaufen bei Amazon"></a>
                      <a href="http://clkde.tradedoubler.com/click?p=23761&a=2023232&url=http://itunes.apple.com/WebObjects/MZSearch.woa/wa/advancedSearchResults?artistTerm=\${kuenstler}&songTerm=\${titel}&albumTerm=&partnerId=2003" 
                      target="_blank"><img src="./images/itune.png" alt="Kaufen bei iTunes"></a></div><div class="plitem"><span class="datum">\${time}</span><span class="artist">
                      \${artist}</span> - <span class="track">\${title}</span></div></li>`, data.tracks);
                      
                if(alreadyAddedToPlaylist.indexOf(data.tracks[0].id)==-1){
                  $(div).prepend(tmpl);
                  alreadyAddedToPlaylist.push(data.tracks[0].id);
                }
                
                var text = request.responseText;
                console.log('Response from CORS request to ' + "flux" + ': ' + text);
            }
        };
        request.send();
    }
}
//////////////////
var locList = ["fluxfm", "fluxkompensator", "clubsandwich", "ohrspiel", "feierstarter"];
var locStream = ["live", "fluxkompensator", "clubsandwich", "ohrspiel", "feierstarter"];

function updateplaylists(number) {
  
    //"http://www.fluxfm.de/fluxfm-playlist/api.php?act=list&cuttime=1&limit=1&loc=berlin"
    //var hashList = ["fluxfm", "fluxkompensator", "clubsandwich", "ohrspiel", "feierstarter"];
    //var locList = ["berlin", "fluxkompensator", "clubsandwich", "ohrspiel", "feierstarter"];
    for(var i=0;i<5;i++){
      var stream = "http://www.fluxfm.de/fluxfm-playlist/api.php?act=list&cuttime=1&limit="+ number +"&loc=" + locList[i];
      var url = encodeURI(stream);
      //console.log(url);
      makeCorsRequest(url);
    }
}



function createPlaylistDiv(i){
  var classname="wrapper";
  if(isActive(i)==="true"){
    classname+=" active_playlist";
  }
  var div =  `<div class="${classname}" id="playlistWrapper${(i)}">
            <div class="station">${locList[i-1]}</div>
            <ul id="playlist_${locList[i-1]}"></ul>
        </div>`;
        return div;
}

function isActive(i){
  var loc = document.location.toLocaleString();
  var hasHash = loc.indexOf("#")>-1;
  value = "false";
  if (hasHash){
    if (loc.indexOf("#"+ locList[i-1])>-1){
      value = "true"; 
    }else{
      value = "false";
    }
  }else{
    if (i===1){
      value = "true";
    }
  }
  return value;
}


function initiateView(){
  window.resizeTo(1024,768);
  var contentLeft = document.getElementsByTagName("fluxplaylistsLeft")[0] || `<div id="fluxplaylistsLeft" class="playlistswrapper">
        ${createPlaylistDiv(1)}
        ${createPlaylistDiv(3)}
        ${createPlaylistDiv(5)}
        
        </div>`;
      //var htmlcontent = $.parseHTML( container );
      $(document.getElementById("player_middle")).prepend(contentLeft );
      
      
      var contentRight = document.getElementsByTagName("fluxplaylistsRight")[0] || 
      `<div id="fluxplaylistsRight" class="playlistswrapper">
              ${createPlaylistDiv(2)}
              ${createPlaylistDiv(4)}
        
      </div>`;
      //var htmlcontent = $.parseHTML( container );
      $(document.getElementById("player_middle")).prepend(contentRight );
      
      
      $("#player_stations ul li").click(updateActivePlaylist);
      $("#player_stations ul li").hover(function() {
        $(".boxShadow").removeClass("boxShadow");
        var wrapper = $("#playlist_" + $( this ).text().toLowerCase()).parent();
        wrapper.addClass("boxShadow");
        
      },function() {
        $(".boxShadow").removeClass("boxShadow");
      
        
      });
      updateActivePlaylist();
      
      
//document.getElementsByTagName("fluxplaylistsLeft")      
}


function updateActivePlaylist() {
         var oldActivePlaylistWrapper = $(".active_playlist");
         var oldActiveId = 1;
         
         if(oldActivePlaylistWrapper[0]){
           oldActiveId = oldActivePlaylistWrapper[0].id.split("playlistWrapper")[1];
         }
         var newActiveName = this.innerText && this.innerText.toLowerCase() || locList[oldActiveId-1];
         var newActivePlaylistWrapper = $("#playlist_"+newActiveName).parent();
         var newActiveId = 1;
         if(newActivePlaylistWrapper[0]){
           newActiveId = newActivePlaylistWrapper[0].id.split("playlistWrapper")[1];
         }
          oldActivePlaylistWrapper.removeClass("active_playlist");
          newActivePlaylistWrapper.addClass("active_playlist"); 
         for(var i=0;i<locList.length;i++){
           var div = $("#playlistWrapper"+(i+1));
           div.removeClass("playlistWrapper" + oldActiveId + "_" + (i+1));
           div.addClass("playlistWrapper" + newActiveId + "_" + (i+1));
         }
          
          
      }
      
      
function isRight(num) { 
  
  return num % 2;
  
}


$( document ).ready(function() {
  initiateView();
  
  updateplaylists(50);
  setInterval(function(){updateplaylists(1);},10000);
});

function addcss(css){
    var head = document.getElementsByTagName('head')[0];
    var s = document.createElement('style');
    s.setAttribute('type', 'text/css');
    if (s.styleSheet) {   // IE
        s.styleSheet.cssText = css;
    } else {                // the world
        s.appendChild(document.createTextNode(css));
    }
    head.appendChild(s);
 }
 
 
 addcss(`
 .playlist{
 white-space: initial;
   
 } 
 .playlistswrapper{
    position: absolute;
    width: 325px;
    height: 470px;
 }

 #playlistWrapper1{
   position:absolute;
   top:0;
   left:0;
 }
 #playlistWrapper3{
   position:absolute;
   top:160px;
   left:0;
 }
 #playlistWrapper5{
   position:absolute;
   top:315px;
   left:0;
 }
 #playlistWrapper2{
   position:absolute;
   top:0;
   left:0;
 }
 #playlistWrapper4{
   position:absolute;
   top:160px;
   left:0;
 }
 ul#Playlist {
    visibility: hidden;
 }
 #fluxplaylistsLeft{
       left: -340px;
 }
 #fluxplaylistsLeft .wrapper{
     
 }
 #fluxplaylistsRight{
   left: 315px;
   
 }
 #fluxplaylistsRight .wrapper{
   
   
 }
 .wrapper {
    height: 150px;
    border: 2px solid #E8E810;
    transition:boxShadow 0.5s, top 2s, left 2s;
     box-shadow : none;
}
.wrapper ul {
    text-align: left;
    list-style: none;
    font-size: 11px;
    overflow-y: auto;
    overflow-x: hidden;
    height:130px;
}
.station{
      text-align: center;
    font-weight: 900;
    font-size: large;
}

.wrapper ul li {
    margin: 0px;
		padding-left: 10px;
		
		padding-bottom: 3px;
		color: #fff;
		background-color: #818181;
}
.boxShadow{
  box-shadow : 0px 0px 18px #2daebf;
}
.wrapper ul li:nth-child(odd) {
  background-color: #595959;
}
li.playlist {
    width: 308px;
    max-width: 308px;
    box-sizing: border-box;
}
li.playlist:first-child {
    font-size: 20px;
    box-sizing: border-box;
    height: 60px;
    display: table-cell;
    vertical-align: middle;
    text-align: center;
}
li.playlist:first-child .plitem span {
    position: relative;
    text-align: center;
    vertical-align: middle;
}`);
addcss(`
/*if playlist 1 3 5 is active*/
 .playlistWrapper1_1, .playlistWrapper3_3, .playlistWrapper5_5{
     top: 184px !important;
    left: 330px !important;
 }
 /*if playlist 2 4 is active*/
 .playlistWrapper2_2, .playlistWrapper4_4{
     top: 184px !important;
    left: -325px !important;
 }
 
 .playlistWrapper1_2, 
 .playlistWrapper1_3, 
 .playlistWrapper2_1, 
 .playlistWrapper2_4,
 .playlistWrapper3_1,
 .playlistWrapper3_2,
 .playlistWrapper4_1,
 .playlistWrapper4_2,
 .playlistWrapper5_1,
 .playlistWrapper5_2{
    top: 0 !important;
    left:0;
 }
 .playlistWrapper1_4, 
 .playlistWrapper1_5,
 .playlistWrapper2_3,
 .playlistWrapper3_4,
 .playlistWrapper3_5,
 .playlistWrapper4_3,
 .playlistWrapper5_3,
 .playlistWrapper5_4{
   top:160px !important;
   left:0;
 }
 
 .playlistWrapper2_5,
 .playlistWrapper4_5{
   top:315px !important;
   left:0;
 }
 
 .playlistWrapper2_5,
 .playlistWrapper4_5{
     top: 160px !important;
    left: 655px !important;
 }
 
  
 `);
